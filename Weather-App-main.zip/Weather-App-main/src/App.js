
import React from 'react'
import './App.css';
import SearchMain from './components/SearchMain';


export default function App() {
  return (
    <div className='App'>
    <SearchMain/>
    </div>
  )
}

